<?php

use Illuminate\Http\Request;

Route::get('getSaks','SaksController@getSaks');
Route::post('addSaks','SaksController@addSaks');
Route::patch('updateSaks','SaksController@updateSaks');
Route::delete('deleteSaks','SaksController@deleteSaks');
Route::post('registerSaks','SaksController@registerSaks');
Route::post('loginSaks','SaksController@loginSaks');