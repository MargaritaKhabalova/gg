<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SasModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class SaksController extends Controller
{
    public function getSaks()
	{
		return response()->json(SasModel::get());
	}

	public function addSaks(Request $req)
	{
		$kaka = Validator::make($req->all(),
			[
				'name'=>'required',
				'surname'=>'required',
				'age'=>'required',
				'login'=>'required',
				'password'=>'required'
			]);
		if($kaka->fails())
			return response()->json($kaka->errors());

		SasModel::create($req->all());
		return response()->json("ok");
	}

	public function updateSaks(Request $req)
	{
		$kaka = SasModel::where('id',$req->id)->first();

        if(!$kaka)
            return response()->json("no");
        
        $kaka->update($req->all());
        return response()->json("ok");
	}

	public function deleteSaks(Request $req)
	{
		$kaka = SasModel::where('id',$req->all())->first();

		if(!$kaka)
			return response()->json("no");

		$kaka->delete();
			return response()->json("ok");
	}

	public function registerSaks(Request $req)
	{
		$voch = Validator::make($req->all(),
			[
				'name'=>'required',
				'surname'=>'required',
				'age'=>'required',
				'login'=>'required',
				'password'=>'required'
			]);
		if($voch ->fails())
			return response()->json($voch ->errors());

		$user = SasModel::create($req->all());
			return response()->json("ok");
	}

	public function loginSaks(Request $req) 
    {
        $voch  = Validator::make($req->all(), [
            'login' => 'required',
            'password' => 'required',
        ]);

        $kaka = SasModel::where('login',$req->login)->first();

        if ($voch ->fails()) {
            if(!$kaka || $req->password!=$kaka->password)
                return response()->json("Логин или пароль введены неверно");
            return response()->json($voch ->errors());
        }

     $kaka->api_token = Str::random(20);
     $kaka->save();
     return response()->json($kaka->name."вы вошли, api_token:".$kaka->api_token);
    }
}
