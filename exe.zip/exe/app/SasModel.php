<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SasModel extends Model
{
	public $table = 'buba';
	public $timestamps = false;

	public $fillable = 
	[
	  'name', 'surname','age','login','password'
	]; 
}
